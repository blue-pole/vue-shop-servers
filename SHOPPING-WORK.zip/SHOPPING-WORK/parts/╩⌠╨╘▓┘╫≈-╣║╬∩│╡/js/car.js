$(function() {
    // 实现商品总计和商品总额的更新
    cartSum();

    // 1.给两个全选按钮加上点击事件，实现全选和全不选控制
    $(".checkall").change(function() {
        $(".j-checkbox, .checkall").prop("checked", $(this).prop("checked"));

        // 被选中的商品更新背景颜色
        selectedUptBG();

        // 实现商品总计和商品总额的更新
        cartSum();
    });

    // 2.给每一个列表中的元素添加全选和不全选的判定，为两个全选按钮同步全选状态信息
    $(".j-checkbox").change(function() {
        if ($(".j-checkbox:checked").length == $(".j-checkbox").length) {
            $(".checkall").prop("checked", true);
        } else {
            $(".checkall").prop("checked", false);
        }

        // 被选中的商品更新背景颜色
        selectedUptBG();

        // 实现商品总计和商品总额的更新
        cartSum();
    });

    // 3.实现点击加号和减号增减商品数量和更新商品小计
    //   实现商品总计和商品总额的更新
    $(".decrement").click(function() {
        var num = $(this).siblings(".itxt").val()
        num--;
        num = num < 1 ? 1 : num;
        $(this).siblings(".itxt").val(num);
        var price = $(this).parents(".p-num").siblings(".p-price").text().substring(1);
        var sum = (price * num).toFixed(2);
        $(this).parents(".p-num").siblings(".p-sum").text("￥" + sum);
        
        // 实现商品总计和商品总额的更新
        cartSum();
    });
    $(".increment").click(function() {
        var num = $(this).siblings(".itxt").val()
        num++;
        num = num < 1 ? 1 : num;
        $(this).siblings(".itxt").val(num);
        var price = $(this).parents(".p-num").siblings(".p-price").text().substring(1);
        var sum = (price * num).toFixed(2);
        $(this).parents(".p-num").siblings(".p-sum").text("￥" + sum);

        // 实现商品总计和商品总额的更新
        cartSum();
    });

    // 4.实现用户直接修改商品数量后更新商品小计
    //   实现商品总计和商品总额的更新
    $(".itxt").change(function() {
        var num = parseInt($(this).val());
        num = num < 1 ? 1 : num;
        var price = $(this).parents(".p-num").siblings(".p-price").text().substring(1);
        var sum = (price * num).toFixed(2);
        $(this).val(num);
        $(this).parents(".p-num").siblings(".p-sum").text("￥" + sum);

        // 实现商品总计和商品总额的更新
        cartSum();
    });

    // 5.实现商品总计和商品总额的更新
    function cartSum() {
        var numSum = 0;
        var priceSum = 0;
        $(".itxt").each(function(index, ele) {
            var selected = $(ele).parents(".p-num").siblings(".p-checkbox").children(".j-checkbox").prop("checked");
            if (selected) {
                numSum += parseInt(ele.value);
                priceSum += parseFloat($(ele).parents(".p-num").siblings(".p-sum").text().substring(1));
            }
        });
        $(".amount-sum em").text(numSum);
        $(".price-sum em").text("￥" + priceSum.toFixed(2));
    }
    
    // 6.实现商品删除，删除选中商品和清空购物车功能
    $(".p-action a").click(function() {
        $(this).parents(".cart-item").remove();
        // 实现商品选择和全选按钮的状态实时更新
        if ($(".j-checkbox").length) {
            $(".j-checkbox").change();
        } else {
            $(".checkall").prop("checked", false);
            // 实现商品总计和商品总额的更新
            cartSum();
        }
    });
    $(".remove-batch").click(function() {
        $(".j-checkbox:checked").parents(".cart-item").remove();
        // 实现商品选择和全选按钮的状态实时更新
        if ($(".j-checkbox").length) {
            $(".j-checkbox").change();
        } else {
            $(".checkall").prop("checked", false);
            // 实现商品总计和商品总额的更新
            cartSum();
        }
    });
    $(".clear-all").click(function() {
        $(".cart-item-list").empty();
        // 实现商品选择和全选按钮的状态实时更新
        if ($(".j-checkbox").length) {
            $(".j-checkbox").change();
        } else {
            $(".checkall").prop("checked", false);
            // 实现商品总计和商品总额的更新
            cartSum();
        }
    });

    // 7.被选中的商品更新背景颜色
    function selectedUptBG() {
        // 被选中的商品更新背景颜色
        $(".j-checkbox").parents(".cart-item").removeClass("check-cart-item");
        $(".j-checkbox:checked").parents(".cart-item").addClass("check-cart-item");
    }
})