$(function() {
    // 在操作数据时，都是先操作本地存储，再把本地存储中的数据渲染到页面上，这样才能保证页面刷新关闭页面不会丢失数据。
    load();
    // 按下回车 把数据存入本地存储
    $("#title").on("keydown", function(ke) {
        if (ke.keyCode === 13) {
            // 先获取本地数据
            var local = getData();

            // 把最新的数据追加到数组的最后面
            local.push({title: $(this).val(), done: false});
            saveData(local);

            // 把本地存好的数据渲染到页面中
            load();
            
            $(this).val("");
        }
    });

    // 删除条目功能实现
    $("ol, ul").on("click", "a", function() {
        var data = getData();
        var index = $(this).attr("id");

        data.splice(index, 1);
        saveData(data);

        load();
    });

    // 正在进行和已经完成条目切换的实现
    $("ol, ul").on("change", "input", function() {
        var data = getData();
        var index = $(this).siblings("a").attr("id");

        data[index].done = $(this).prop("checked");
        saveData(data);

        load();
    });

    // 读取本地存储中的数据
    function getData() {
        var data = window.localStorage.getItem("todolist");
        if (data) {
            return JSON.parse(data);
        } else {
            return [];
        }
    }
    // 将数据存入本地存储
    function saveData(data) {
        window.localStorage.setItem("todolist", JSON.stringify(data));
    }
    // 把本地存好的数据渲染到页面中
    function load() {
        var data = getData();
        $("ol, ul").empty();
        var todoCount = 0;
        var doneCount = 0;
        $.each(data, function(i, n) {
            if (n.done) {
                $("ul").prepend('<li><input type="checkbox" checked><p class="doing-text">' + n.title + '</p><a id="' + i + '" href="javascript:;"></a></li>');
                doneCount++;
            } else {
                $("ol").prepend('<li><input type="checkbox"><p class="doing-text">' + n.title + '</p><a id="' + i + '" href="javascript:;"></a></li>');
                todoCount++;
            }
        });
        $("#todocount").text(todoCount);
        $("#donecount").text(doneCount);
    }
})