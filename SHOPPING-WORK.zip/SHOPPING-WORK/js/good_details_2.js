window.addEventListener('load', function() {
    var preview_img = this.document.querySelector('.picture');
    var mask = this.document.querySelector('.mask');
    var big = this.document.querySelector('.big');

    var bg = document.createElement('div');
    big.appendChild(bg);
    bg.style.background = 'url("../upload/产品详情页/banner/big_picture.png") no-repeat center';

    preview_img.addEventListener('mouseover', function() {
        mask.style.display = 'block';
        big.style.display = 'block';

        var zoomRate = big.offsetWidth / mask.offsetWidth;
        bg.style.width = preview_img.offsetWidth * zoomRate + 'px';
        bg.style.height = preview_img.offsetHeight * zoomRate + 'px';
        bg.style.backgroundColor = '#fff';
        bg.style.backgroundSize = preview_img.children[0].offsetWidth * zoomRate + 'px ' + preview_img.children[0].offsetHeight * zoomRate + 'px';
    });

    preview_img.addEventListener('mouseout', function() {
        mask.style.display = 'none';
        big.style.display = 'none';  
    })

    preview_img.addEventListener('mousemove', function(me) {
        var x = me.pageX - this.offsetLeft;
        var y = me.pageY - this.offsetTop;

        var maskX = x - mask.offsetWidth / 2;
        var maskY = y - mask.offsetHeight / 2;
        // 遮挡层的最大移动距离
        var maskMax = preview_img.offsetWidth - mask.offsetWidth;
        maskX = (maskX < 0) ? 0 : maskX;
        maskX = (maskX > maskMax) ? maskMax : maskX;
        maskY = (maskY < 0) ? 0 : maskY;
        maskY = (maskY > maskMax) ? maskMax : maskY;
        mask.style.left = maskX + 'px';
        mask.style.top = maskY + 'px';

        // 大图片的移动距离 / 大图片的最大移动距离 = 遮挡层的移动距离 / 遮挡层的最大移动距离
        // 大图片的移动距离
        var bigMax = bg.offsetWidth - big.offsetWidth;
        var bigX = maskX * bigMax / maskMax;
        var bigY = maskY * bigMax / maskMax;
        bg.style.marginLeft = -bigX + 'px';
        bg.style.marginTop = -bigY + 'px';
    });
});