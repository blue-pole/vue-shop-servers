window.addEventListener('load', function() {
    // banner-left-picture
    var pic = this.document.querySelector('.banner .left .picture');
    var zoomArea = this.document.querySelector('.banner .left .zoom_in_area');
    var zoomPic = this.document.querySelector('.banner .left .zoom_in_picture');
    var zoomBg = pic.cloneNode(true);
    var zoomBgPic = zoomBg.children[0];
    var zoomRate = 2;
    // var holdRate = 1.5;
    //此时，zoomPic,zoomBg 和 zoomBgPic是display:none;，因此offset系列值都为0。
    zoomBg.style.width = pic.offsetWidth * zoomRate + 'px';
    zoomBg.style.height = pic.offsetHeight * zoomRate + 'px';
    zoomBg.style.lineHeight = pic.offsetHeight * zoomRate  + 'px';
    zoomBgPic.style.width = pic.children[0].offsetWidth * zoomRate + 'px';
    zoomBgPic.style.height = pic.children[0].offsetHeight * zoomRate + 'px';
    zoomBg.style.border = 'none';
    zoomPic.appendChild(zoomBg);

    document.addEventListener('mousemove', function(me) {
        if ((me.pageX >= pic.offsetLeft && me.pageX <= pic.offsetLeft + pic.offsetWidth) && (me.pageY >= pic.offsetTop && me.pageY <= pic.offsetTop + pic.offsetHeight)) {
            zoomArea.style.cursor = 'move';
            zoomArea.style.display = 'block';
            zoomPic.style.display = 'block';
    
            // 注意，此处应该考虑父盒子是否有position属性。
            // 由于pic的所有父盒子都没有设定position属性，因此，不需要关注父盒子
            var mouseX = me.pageX - pic.offsetLeft;
            var mouseY = me.pageY - pic.offsetTop;
            // zoomArea
            // zoomAreaX:min+200 ~ max-200
            var zoomAreaX = fence(mouseX, zoomArea.offsetWidth / 2, pic.offsetWidth - (zoomArea.offsetWidth / 2));
            var zoomAreaY = fence(mouseY, zoomArea.offsetHeight / 2, pic.offsetHeight - (zoomArea.offsetHeight / 2)) - pic.offsetHeight;
            zoomArea.style.left = zoomAreaX  + 'px';
            zoomArea.style.top = zoomAreaY + 'px';
            // zoomPic
            // zoomAreaX / pic.offsetWidth = -(zoomBg.style.left) / zoomBg.offsetWidth
            zoomBg.style.marginLeft = -((zoomAreaX - zoomArea.offsetWidth / 2) * zoomBg.offsetWidth / pic.offsetWidth) + 'px';
            zoomBg.style.marginTop = -((zoomAreaY + pic.offsetHeight - zoomArea.offsetHeight / 2) * zoomBg.offsetHeight / pic.offsetHeight) + 'px';
        } else {
            pic.removeAttribute('style');
            zoomArea.removeAttribute('style');
            zoomPic.removeAttribute('style');
        }
    });

    function fence(sheep, min, max) {
        if (sheep < min) {
            return min;
        } else if (sheep > max) {
            return max;
        }
        return sheep;
    }
});