window.addEventListener("load", function() {
// ========================================================================================
// 功能一：商品条目中的复选框选中状态变化时的背景颜色管理
// ========================================================================================
// ----------------------------------------------------------------------------------------
// 功能逻辑
// ----------------------------------------------------------------------------------------
let selectList = document.querySelectorAll(".shop_list input[name='good_select']");
// ----------------------------------------------------------------------------------------
// 功能工具函数
// ----------------------------------------------------------------------------------------
function goodItemBgcManager(item) {
    let checkbox = item.querySelector("input[name='good_select']");
    checkbox.checked ? item.classList.add("selected_element") : item.classList.remove("selected_element");
}
// ========================================================================================

// ========================================================================================
// 功能二：选择复选框的管理
// 1. 点击全选复选框，所有商品的复选框会作出反应,其它全选复选框也会做出反应。
// 2. 点击商店的全选复选框，所有该商店的商品的复选框会作出反应。
// 3. 点击商店的全选复选框，所有全选复选框也会作出反应。
// 4. 商品选中状态改变后，选中商品总数和选中商品价格总计也要作出反应。
// ========================================================================================
// ----------------------------------------------------------------------------------------
// 功能逻辑
// ----------------------------------------------------------------------------------------
let selectAllList = document.querySelectorAll("input[name='select_all']");
let selectStoreAllList = document.querySelectorAll("input[name='select_store_all']");
// 1. 点击全选复选框，所有商品的复选框会作出反应,其它全选复选框也会做出反应。
selectManager(selectAllList, selectList, function(selectAllList, selectList) {
    selectList.forEach(element => {
        goodItemBgcManager(element.parentNode.parentNode.parentNode.parentNode);
    });

    updateSumPrice();
    updateSumCount();
});
// 2. 点击商店的全选复选框，所有该商店的商品的复选框会作出反应。
let shopGoodsLists = document.querySelectorAll(".shop_goods_list");
for (let index = 0; index < shopGoodsLists.length; index++) {
    let selectStoreAll = shopGoodsLists[index].querySelector("input[name='select_store_all']");
    let selectList = shopGoodsLists[index].querySelectorAll("input[name='good_select']");
    selectManager([selectStoreAll], selectList, function(selectAllList, selectList) {
        selectList.forEach(element => {
            goodItemBgcManager(element.parentNode.parentNode.parentNode.parentNode);
        });

        updateSumPrice();
        updateSumCount();
    });
}
// 3. 点击商店的全选复选框，所有全选复选框也会做出反应。
selectManager(selectAllList, selectStoreAllList, function() {
    updateSumPrice();
    updateSumCount();
});
// ----------------------------------------------------------------------------------------
// 功能工具函数
// ----------------------------------------------------------------------------------------
function selectManager(selectAllList, selectList, doMore) {
    // 全选按钮对单选按钮的控制，全选按钮对全选按钮的控制
    for (let selectAllIndex = 0; selectAllIndex < selectAllList.length; selectAllIndex++) {
        selectAllList[selectAllIndex].addEventListener('change', function() {
            for (let selectIndex = 0; selectIndex < selectList.length; selectIndex++) {
                selectList[selectIndex].checked = this.checked;
            }
            for (let selectAllIndex = 0; selectAllIndex < selectAllList.length; selectAllIndex++) {
                selectAllList[selectAllIndex].checked = this.checked;
            }
            if (doMore) {
                doMore(selectAllList, selectList);
            }
        });
    }
    // 单选按钮对全选按钮的控制
    for (let selectIndex = 0; selectIndex < selectList.length; selectIndex++) {
        selectList[selectIndex].addEventListener('change', function() {
            let selectedCount = 0;
            let allSelected = false;
            for (let selectIndex = 0; selectIndex < selectList.length; selectIndex++) {
                if (selectList[selectIndex].checked) selectedCount++;
            }
            selectedCount === selectList.length ? allSelected = true : allSelected = false;
            for (let selectAllIndex = 0; selectAllIndex < selectAllList.length; selectAllIndex++) {
                selectAllList[selectAllIndex].checked = allSelected;
            }
            if (doMore) {
                doMore(selectAllList, selectList);
            }
        });
    }
}
// ========================================================================================

// ========================================================================================
// 功能三：点击“+”按钮，数量加1；点击“-”按钮，数量减一
// 1.数量只能为>=0的整数
// 2.点击后每个商品的小计也要更新
// 3.用户输入商品数量后，商品的小计也要更新
// 4.商品小计改变后，选中商品的总价也得更新
// ========================================================================================
// ----------------------------------------------------------------------------------------
// 功能逻辑
// ----------------------------------------------------------------------------------------
let addBtns = $(".goods_list_element .count .num .good_add");
let reduceBtns = $(".goods_list_element .count .num .good_reduce");
let goodCounts = $(".goods_list_element .count .num .good_count");
for (let index = 0; index < addBtns.length; index++) {
    addBtns[index].addEventListener("selectstart", function(e){
        e.preventDefault();
    });
}
addBtns.click(function() {
    let goodCount = parseInt($(this).siblings(".good_count").val());
    let goodPrice = $(this).parents(".goods_list_element").find(".price").html();
    goodCount++;
    goodCount = goodCount >= 1 ? goodCount : 1;
    goodCount = goodCount > 999 ? 999 : goodCount;
    $(this).siblings(".good_count").val(goodCount);
    $(this).parents(".goods_list_element").find(".sum").html((goodCount * goodPrice).toFixed(2));

    updateSumPrice();
})
for (let index = 0; index < reduceBtns.length; index++) {
    reduceBtns[index].addEventListener("selectstart", function(e){
        e.preventDefault();
    });
}
reduceBtns.click(function() {
    let goodCount = parseInt($(this).siblings(".good_count").val());
    let goodPrice = $(this).parents(".goods_list_element").find(".price").html();
    goodCount--;
    goodCount = goodCount >= 1 ? goodCount : 1;
    goodCount = goodCount > 999 ? 999 : goodCount;
    $(this).siblings(".good_count").val(goodCount);
    $(this).parents(".goods_list_element").find(".sum").html((goodCount * goodPrice).toFixed(2));

    updateSumPrice();
})
goodCounts.blur(function() {
    let goodCount = parseInt($(this).val());
    let goodPrice = $(this).parents(".goods_list_element").find(".price").html();
    goodCount = goodCount >= 1 ? goodCount : 1;
    goodCount = goodCount > 999 ? 999 : goodCount;
    $(this).val(goodCount);
    $(this).parents(".goods_list_element").find(".sum").html((goodCount * goodPrice).toFixed(2));

    updateSumPrice();
})
// ----------------------------------------------------------------------------------------
// 功能工具函数
// ----------------------------------------------------------------------------------------
// ========================================================================================

// ========================================================================================
// 功能四：点击删除，删除本条目  【未完成】没有完成从删除条目复原的功能
// 1.当一个商店中没有一件商品在购物车内时，这个商店的信息也不能存在于购物车中。
// 2.被删除的条目被移到【已删除商品列表】的第一条。
// 3.【已删除商品列表】中的条目可以重新添加到购物车中。
// 4.【已删除商品列表】最多只能保存10条数据。
// 5.删除或复原商品后都要更新已选商品总件数，和总价格。
// 6.点击【删除选中的商品】按钮后，所有选中的商品都要被删除。
// 实现思路：还是得为每一件商品创建一条单独的数据，存到sessionStorage中。
// ========================================================================================
// ----------------------------------------------------------------------------------------
// 功能逻辑
// ----------------------------------------------------------------------------------------
let deleteItem = $(".goods_list_element .delete");
deleteItem.click(toDeleteItem);

let deleteSelectedBtn = $(".selected_goods_sum .good_actions .selected_delete");
deleteSelectedBtn.click(function() {
    forSelectedItems(function(selectedItem) {
        selectedItem.find(".delete").click();
    });
});
// ----------------------------------------------------------------------------------------
// 功能工具函数
// ----------------------------------------------------------------------------------------
function toDeleteItem() {
    let storeItemCount = $(this).parents(".shop_goods_list").children(".goods_list_element").length;
    let deleteItem = $(this).parents(".goods_list_element");
    let itemInfo = {
        description: "",
        price: deleteItem.find(".price").text(),
        count: deleteItem.find(".good_count").val()
    }
    let itemDescriptionNodes = deleteItem.find(".good_description")[0].childNodes;
    for (let i = 0; i < itemDescriptionNodes.length; i++) {
        let node = itemDescriptionNodes[i];
        if (node.nodeName === "#text") {
            let value = node.nodeValue.trim();
            itemInfo.description += (value + " ")
        }
    }
    itemInfo.description = itemInfo.description.trim();
    let deletedItemList = $(".deleted_good_list");
    let deletedItem = $(
        `<li>
            <ul class="deleted_good_inform clearfix">
                <li class="description">${itemInfo.description}</li>
                <li class="price">${itemInfo.price}</li>
                <li class="count">${itemInfo.count}</li>
                <li class="actions">
                    <ul class="clearfix">
                        <li>重新购买</li>
                        <li>移到我的关注</li>
                    </ul>
                </li>
            </ul>
        </li>`);
    deletedItemList.prepend(deletedItem);

    if (storeItemCount > 1) {
        deleteItem.remove();
    } else {
        $(this).parents(".shop_goods_list").remove();
    }

    updateSumPrice();
    updateSumCount();
}

function forSelectedItems(dosome) {
    let goodItems = $(".shop_goods_list").children(".selected_element")
    for (let i = 0; i < goodItems.length; i++) {
        dosome(goodItems.eq(i));
    }
}
// ========================================================================================

// ========================================================================================
// 功能五：统计购物车中商品总数和总价
// ========================================================================================
// ----------------------------------------------------------------------------------------
// 功能逻辑
// ----------------------------------------------------------------------------------------
updateSumPrice();
updateSumCount();
// ----------------------------------------------------------------------------------------
// 功能工具函数
// ----------------------------------------------------------------------------------------
function updateSumPrice() {
    let selectedGoodsPriceSum = 0;
    forSelectedItems(function(selectedItem) {
        selectedGoodsPriceSum += parseInt(selectedItem.find(".sum").text());
    });
    $(".selected_goods_sum .sum .sum_pay").html(selectedGoodsPriceSum.toFixed(2));
}
function updateSumCount() {
    let goodItems = $(".shop_goods_list").children(".goods_list_element")
    let goodsCountSum = goodItems.length;
    $(".shopping_car_goods").children("h3").children(".goods_count").html(goodsCountSum);
    
    let selectedGoodsCountSum = 0;
    forSelectedItems(function(selectedItem) {
        selectedGoodsCountSum ++;
    });
    $(".selected_goods_sum .sum .count").html(selectedGoodsCountSum);
}
// ========================================================================================

// ========================================================================================
// 功能六：
// ========================================================================================
// ----------------------------------------------------------------------------------------
// 功能逻辑
// ----------------------------------------------------------------------------------------
updateSumPrice();
updateSumCount();
// ----------------------------------------------------------------------------------------
// 功能工具函数
// ----------------------------------------------------------------------------------------
});
